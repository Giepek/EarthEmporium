from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db.models import Avg


class Machine(models.Model):
    TYPE_CHOICES = [
        ('gasienicowa', 'Koparka gąsienicowa'),
        ('kolowa', 'Koparka kołowa'),
        ('mini', 'Mini koparka'),
    ]
    STATUS_CHOICES = [
        ('dostepna', 'Dostępna'),
        ('na_sprzedaz', 'Na sprzedaż'),
        ('wypozyczona', 'Wypożyczona'),
        ('nowa', 'Nowa'),
    ]
    BRAND_CHOICES = [
        ('CAT', 'CAT'),
        ('Komatsu', 'Komatsu'),
        ('Volvo', 'Volvo'),
        ('Liebherr', 'Liebherr'),
        ('JCB', 'JCB'),
        ('Hitachi', 'Hitachi'),
        ('Inne', 'Inne'),
    ]
    COLOR_CHOICES = [
        ('#2e7d32', 'Zielony'),
        ('#e65100', 'Pomarańczowy'),
        ('#1565c0', 'Niebieski'),
        ('#6a1b9a', 'Fioletowy'),
        ('#37474f', 'Szary'),
    ]

    name = models.CharField(max_length=100, verbose_name='Nazwa')
    machine_type = models.CharField(max_length=20, choices=TYPE_CHOICES, verbose_name='Typ')
    brand = models.CharField(max_length=20, choices=BRAND_CHOICES, verbose_name='Marka')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='dostepna', verbose_name='Status')
    year = models.IntegerField(verbose_name='Rok produkcji')
    weight_kg = models.IntegerField(verbose_name='Masa robocza (kg)', null=True, blank=True)
    digging_depth_m = models.FloatField(verbose_name='Głębokość kopania (m)', null=True, blank=True)
    bucket_capacity_m3 = models.FloatField(verbose_name='Pojemność łyżki (m³)', null=True, blank=True)
    engine_power_kw = models.IntegerField(verbose_name='Moc silnika (kW)', null=True, blank=True)
    rental_price_per_day = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name='Cena wynajmu (zł/dzień)')
    sale_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True, verbose_name='Cena sprzedaży (zł)')
    description = models.TextField(blank=True, verbose_name='Opis')
    image = models.FileField(upload_to='machines/', null=True, blank=True, verbose_name='Zdjęcie')
    card_color = models.CharField(max_length=20, choices=COLOR_CHOICES, default='#2e7d32', verbose_name='Kolor karty')
    is_featured = models.BooleanField(default=False, verbose_name='Polecana')
    wiki_url = models.URLField(max_length=500, blank=True, null=True, verbose_name='Link do Wikipedia')
    youtube_url = models.URLField(max_length=500, blank=True, null=True, verbose_name='Link do YouTube')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Maszyna'
        verbose_name_plural = 'Maszyny'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.name} ({self.get_status_display()})"

    def get_status_badge_class(self):
        classes = {
            'dostepna': 'badge-dostepna',
            'na_sprzedaz': 'badge-sprzedaz',
            'wypozyczona': 'badge-wypozyczona',
            'nowa': 'badge-nowa',
        }
        return classes.get(self.status, 'badge-dostepna')

    def get_avg_rating(self):
        """Zwraca średnią ocenę (float) lub None jeśli brak ocen."""
        result = self.ratings.aggregate(avg=Avg('rating'))['avg']
        return round(result, 1) if result else None

    def get_rating_count(self):
        return self.ratings.count()


# ─────────────────────────────────────────────
#  WISHLIST
# ─────────────────────────────────────────────

class Wishlist(models.Model):
    user    = models.ForeignKey(User, on_delete=models.CASCADE, related_name='wishlist', verbose_name='Użytkownik')
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE, related_name='wishlisted_by', verbose_name='Maszyna')
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Ulubiona maszyna'
        verbose_name_plural = 'Ulubione maszyny'
        unique_together = ('user', 'machine')

    def __str__(self):
        return f"{self.user.username} ♥ {self.machine.name}"


# ─────────────────────────────────────────────
#  OCENY / RATING
# ─────────────────────────────────────────────

class MachineRating(models.Model):
    user    = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ratings', verbose_name='Użytkownik')
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE, related_name='ratings', verbose_name='Maszyna')
    rating  = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name='Ocena (1–5)',
    )
    comment  = models.TextField(blank=True, verbose_name='Komentarz')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Ocena maszyny'
        verbose_name_plural = 'Oceny maszyn'
        unique_together = ('user', 'machine')
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} → {self.machine.name}: {self.rating}★"


# ─────────────────────────────────────────────
#  POZOSTAŁE MODELE (bez zmian)
# ─────────────────────────────────────────────

class RentalRequest(models.Model):
    STATUS_CHOICES = [
        ('oczekuje', 'Oczekuje'),
        ('potwierdzona', 'Potwierdzona'),
        ('odrzucona', 'Odrzucona'),
        ('zakonczona', 'Zakończona'),
    ]

    machine    = models.ForeignKey(Machine, on_delete=models.CASCADE, related_name='rentals', verbose_name='Maszyna')
    user       = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='Użytkownik')
    full_name  = models.CharField(max_length=100, verbose_name='Imię i nazwisko')
    email      = models.EmailField(verbose_name='Adres e-mail')
    phone      = models.CharField(max_length=20, verbose_name='Numer telefonu')
    start_date = models.DateField(verbose_name='Data rozpoczęcia')
    end_date   = models.DateField(verbose_name='Data zakończenia')
    total_cost = models.DecimalField(max_digits=12, decimal_places=2, verbose_name='Koszt całkowity')
    status     = models.CharField(max_length=20, choices=STATUS_CHOICES, default='oczekuje', verbose_name='Status')
    notes      = models.TextField(blank=True, verbose_name='Uwagi')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Rezerwacja'
        verbose_name_plural = 'Rezerwacje'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.full_name} — {self.machine.name} ({self.start_date} – {self.end_date})"

    def get_days(self):
        return (self.end_date - self.start_date).days


class PurchaseRequest(models.Model):
    STATUS_CHOICES = [
        ('oczekuje', 'Oczekuje'),
        ('potwierdzona', 'Potwierdzona'),
        ('odrzucona', 'Odrzucona'),
    ]

    machine   = models.ForeignKey(Machine, on_delete=models.CASCADE, related_name='purchases', verbose_name='Maszyna')
    user      = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='Użytkownik')
    full_name = models.CharField(max_length=100, verbose_name='Imię i nazwisko')
    email     = models.EmailField(verbose_name='Adres e-mail')
    phone     = models.CharField(max_length=20, verbose_name='Numer telefonu')
    message   = models.TextField(blank=True, verbose_name='Wiadomość')
    status    = models.CharField(max_length=20, choices=STATUS_CHOICES, default='oczekuje', verbose_name='Status')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Zapytanie o zakup'
        verbose_name_plural = 'Zapytania o zakup'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.full_name} — {self.machine.name}"
