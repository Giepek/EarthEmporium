from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('katalog/', views.catalog, name='catalog'),
    path('maszyna/<int:pk>/', views.machine_detail, name='machine_detail'),
    path('wypozycz/<int:pk>/', views.rental_form, name='rental_form'),
    path('rezerwacja-sukces/<int:pk>/', views.rental_success, name='rental_success'),
    path('kup/<int:pk>/', views.purchase_form, name='purchase_form'),
    path('zakup-sukces/<int:pk>/', views.purchase_success, name='purchase_success'),
    path('kontakt/', views.contact, name='contact'),
    path('statystyki/', views.admin_stats, name='admin_stats'),
    path('porownaj/', views.compare_machines, name='compare_machines'),
    path('dodaj-do-porownania/<int:pk>/', views.add_to_compare, name='add_to_compare'),
    path('usun-z-porownania/<int:pk>/', views.remove_from_compare, name='remove_from_compare'),
    path('wyczysc-porownanie/', views.clear_compare, name='clear_compare'),
    path('platnosc/<int:pk>/', views.payment_form, name='payment_form'),
    path('platnosc-sukces/<int:pk>/', views.payment_success, name='payment_success'),

    # ── Wishlist ──────────────────────────────────────────────
    path('ulubione/', views.wishlist_view, name='wishlist'),
    path('ulubione/toggle/<int:pk>/', views.toggle_wishlist, name='toggle_wishlist'),

    # ── Oceny ─────────────────────────────────────────────────
    path('maszyna/<int:pk>/ocen/', views.rate_machine, name='rate_machine'),
    path('maszyna/<int:pk>/usun-ocene/', views.delete_rating, name='delete_rating'),
]
