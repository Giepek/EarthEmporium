from django import template
import re

register = template.Library()

@register.filter
def youtube_id(url):
    """Wyciąga ID filmu z linku YouTube"""
    if not url:
        return ''
    
    # Różne formaty linków YouTube
    patterns = [
        r'(?:youtube\.com\/watch\?v=)([^&\s]+)',
        r'(?:youtu\.be\/)([^?\s]+)',
        r'(?:youtube\.com\/embed\/)([^?\s]+)',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    
    return url