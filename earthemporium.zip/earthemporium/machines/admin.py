from django.contrib import admin
from .models import Machine, RentalRequest, PurchaseRequest


@admin.register(Machine)
class MachineAdmin(admin.ModelAdmin):
    list_display = ['name', 'brand', 'machine_type', 'status', 'rental_price_per_day', 'sale_price', 'is_featured']
    list_filter = ['machine_type', 'status', 'brand', 'is_featured']
    search_fields = ['name', 'description']
    list_editable = ['status', 'is_featured']
    ordering = ['-created_at']


@admin.register(RentalRequest)
class RentalRequestAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'machine', 'start_date', 'end_date', 'total_cost', 'status', 'created_at']
    list_filter = ['status', 'created_at']
    search_fields = ['full_name', 'email', 'machine__name']
    list_editable = ['status']
    ordering = ['-created_at']


@admin.register(PurchaseRequest)
class PurchaseRequestAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'machine', 'email', 'phone', 'status', 'created_at']
    list_filter = ['status', 'created_at']
    search_fields = ['full_name', 'email', 'machine__name']
    list_editable = ['status']
    ordering = ['-created_at']
