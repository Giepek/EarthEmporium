from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.db.models import Q, Avg
from decimal import Decimal
from .models import Machine, RentalRequest, PurchaseRequest, Wishlist, MachineRating
from .forms import RentalForm, PurchaseForm, MachineFilterForm
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Sum, Count
import json


def home(request):
    featured_machines = Machine.objects.filter(is_featured=True)[:8]
    total_machines = Machine.objects.count()
    available_machines = Machine.objects.filter(status='dostepna').count()

    context = {
        'featured_machines': featured_machines,
        'total_machines': total_machines,
        'available_machines': available_machines,
    }
    return render(request, 'home.html', context)


def catalog(request):
    machines = Machine.objects.all()
    form = MachineFilterForm(request.GET)

    if form.is_valid():
        machine_type = form.cleaned_data.get('machine_type')
        status       = form.cleaned_data.get('status')
        brand        = form.cleaned_data.get('brand')
        price_min    = form.cleaned_data.get('price_min')
        price_max    = form.cleaned_data.get('price_max')
        sort         = form.cleaned_data.get('sort')
        search       = form.cleaned_data.get('search')

        if machine_type:
            machines = machines.filter(machine_type=machine_type)
        if status:
            machines = machines.filter(status=status)
        if brand:
            machines = machines.filter(brand=brand)
        if search:
            machines = machines.filter(
                Q(name__icontains=search) |
                Q(brand__icontains=search) |
                Q(description__icontains=search)
            )
        if price_min is not None:
            machines = machines.filter(
                Q(rental_price_per_day__gte=price_min) | Q(sale_price__gte=price_min)
            )
        if price_max is not None:
            machines = machines.filter(
                Q(rental_price_per_day__lte=price_max) | Q(sale_price__lte=price_max)
            )

        if sort == 'price_asc':
            machines = machines.order_by('rental_price_per_day', 'sale_price')
        elif sort == 'price_desc':
            machines = machines.order_by('-rental_price_per_day', '-sale_price')
        elif sort == 'name_asc':
            machines = machines.order_by('name')
        elif sort == 'newest':
            machines = machines.order_by('-created_at')
        else:
            machines = machines.order_by('rental_price_per_day', 'sale_price')

    # Wishlist IDs dla zalogowanego użytkownika
    wishlist_ids = set()
    if request.user.is_authenticated:
        wishlist_ids = set(
            Wishlist.objects.filter(user=request.user).values_list('machine_id', flat=True)
        )

    context = {
        'machines': machines,
        'form': form,
        'count': machines.count(),
        'brands_list': ['CAT', 'Komatsu', 'Volvo', 'Liebherr', 'JCB', 'Hitachi'],
        'wishlist_ids': wishlist_ids,
    }
    return render(request, 'machines/catalog.html', context)


def machine_detail(request, pk):
    machine = get_object_or_404(Machine, pk=pk)
    similar = Machine.objects.filter(machine_type=machine.machine_type).exclude(pk=pk)[:3]

    # Wishlist
    in_wishlist = (
        request.user.is_authenticated and
        Wishlist.objects.filter(user=request.user, machine=machine).exists()
    )

    # Oceny
    ratings     = machine.ratings.select_related('user').all()
    avg_rating  = machine.get_avg_rating()
    rating_count = machine.get_rating_count()

    # Czy użytkownik już ocenił?
    user_rating = None
    if request.user.is_authenticated:
        user_rating = MachineRating.objects.filter(user=request.user, machine=machine).first()

    context = {
        'machine': machine,
        'similar': similar,
        'in_wishlist': in_wishlist,
        'ratings': ratings,
        'avg_rating': avg_rating,
        'rating_count': rating_count,
        'user_rating': user_rating,
        'star_range': range(1, 6),
    }
    return render(request, 'machines/machine_detail.html', context)


# ─────────────────────────────────────────────
#  WISHLIST
# ─────────────────────────────────────────────

@login_required
def toggle_wishlist(request, pk):
    """Dodaj / usuń z ulubionych. Obsługuje AJAX i zwykły redirect."""
    machine = get_object_or_404(Machine, pk=pk)
    obj, created = Wishlist.objects.get_or_create(user=request.user, machine=machine)

    if not created:
        obj.delete()
        in_wishlist = False
        msg = f'„{machine.name}" usunięto z ulubionych.'
    else:
        in_wishlist = True
        msg = f'„{machine.name}" dodano do ulubionych!'

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'in_wishlist': in_wishlist, 'message': msg})

    messages.success(request, msg)
    return redirect(request.META.get('HTTP_REFERER', 'catalog'))


@login_required
def wishlist_view(request):
    items = Wishlist.objects.filter(user=request.user).select_related('machine').order_by('-added_at')
    return render(request, 'machines/wishlist.html', {'items': items})


# ─────────────────────────────────────────────
#  OCENY (RATING)
# ─────────────────────────────────────────────

@login_required
def rate_machine(request, pk):
    """Dodaj lub zaktualizuj ocenę maszyny."""
    machine = get_object_or_404(Machine, pk=pk)

    if request.method != 'POST':
        return redirect('machine_detail', pk=pk)

    try:
        rating_value = int(request.POST.get('rating', 0))
    except (ValueError, TypeError):
        rating_value = 0

    if not (1 <= rating_value <= 5):
        messages.error(request, 'Nieprawidłowa ocena. Wybierz od 1 do 5 gwiazdek.')
        return redirect('machine_detail', pk=pk)

    comment = request.POST.get('comment', '').strip()

    obj, created = MachineRating.objects.update_or_create(
        user=request.user,
        machine=machine,
        defaults={'rating': rating_value, 'comment': comment},
    )

    if created:
        messages.success(request, f'Dodano ocenę {rating_value}★ dla „{machine.name}".')
    else:
        messages.success(request, f'Zaktualizowano ocenę do {rating_value}★.')

    return redirect('machine_detail', pk=pk)


@login_required
def delete_rating(request, pk):
    """Usuń własną ocenę."""
    machine = get_object_or_404(Machine, pk=pk)
    MachineRating.objects.filter(user=request.user, machine=machine).delete()
    messages.success(request, 'Twoja ocena została usunięta.')
    return redirect('machine_detail', pk=pk)


# ─────────────────────────────────────────────
#  POZOSTAŁE WIDOKI (bez zmian)
# ─────────────────────────────────────────────

def rental_form(request, pk):
    machine = get_object_or_404(Machine, pk=pk)

    if machine.status not in ['dostepna', 'nowa']:
        messages.error(request, 'Ta maszyna nie jest dostępna do wypożyczenia.')
        return redirect('machine_detail', pk=pk)

    if request.method == 'POST':
        form = RentalForm(request.POST)
        if form.is_valid():
            rental = form.save(commit=False)
            rental.machine = machine
            if request.user.is_authenticated:
                rental.user = request.user
            days = (rental.end_date - rental.start_date).days
            rental.total_cost = Decimal(days) * machine.rental_price_per_day
            rental.save()
            messages.success(request, 'Rezerwacja złożona pomyślnie! Skontaktujemy się z Tobą wkrótce.')
            return redirect('payment_form', pk=rental.pk)
    else:
        initial = {}
        if request.user.is_authenticated:
            initial['full_name'] = f"{request.user.first_name} {request.user.last_name}".strip()
            initial['email'] = request.user.email
        form = RentalForm(initial=initial)

    return render(request, 'machines/rental_form.html', {'machine': machine, 'form': form})


def rental_success(request, pk):
    rental = get_object_or_404(RentalRequest, pk=pk)
    return render(request, 'machines/rental_success.html', {'rental': rental})


def purchase_form(request, pk):
    machine = get_object_or_404(Machine, pk=pk)

    if machine.status not in ['na_sprzedaz', 'nowa']:
        messages.error(request, 'Ta maszyna nie jest dostępna do zakupu.')
        return redirect('machine_detail', pk=pk)

    if request.method == 'POST':
        form = PurchaseForm(request.POST)
        if form.is_valid():
            purchase = form.save(commit=False)
            purchase.machine = machine
            if request.user.is_authenticated:
                purchase.user = request.user
            purchase.save()
            messages.success(request, 'Zapytanie o zakup zostało wysłane! Skontaktujemy się z Tobą.')
            return redirect('purchase_success', pk=purchase.pk)
    else:
        initial = {}
        if request.user.is_authenticated:
            initial['full_name'] = f"{request.user.first_name} {request.user.last_name}".strip()
            initial['email'] = request.user.email
        form = PurchaseForm(initial=initial)

    return render(request, 'machines/purchase_form.html', {'machine': machine, 'form': form})


def purchase_success(request, pk):
    purchase = get_object_or_404(PurchaseRequest, pk=pk)
    return render(request, 'machines/purchase_success.html', {'purchase': purchase})


def contact(request):
    if request.method == 'POST':
        name    = request.POST.get('name')
        email   = request.POST.get('email')
        message = request.POST.get('message')
        if name and email and message:
            messages.success(request, 'Wiadomość wysłana! Odpiszemy wkrótce.')
            return redirect('contact')
        else:
            messages.error(request, 'Wypełnij wszystkie pola.')
    return render(request, 'contact.html')


@staff_member_required
def admin_stats(request):
    total_machines    = Machine.objects.count()
    available_machines = Machine.objects.filter(status='dostepna').count()
    rented_machines   = Machine.objects.filter(status='wypozyczona').count()
    for_sale_machines = Machine.objects.filter(status='na_sprzedaz').count()
    total_rentals     = RentalRequest.objects.count()
    pending_rentals   = RentalRequest.objects.filter(status='oczekuje').count()
    confirmed_rentals = RentalRequest.objects.filter(status='potwierdzona').count()
    total_revenue     = RentalRequest.objects.filter(status='potwierdzona').aggregate(Sum('total_cost'))['total_cost__sum'] or 0
    total_purchases   = PurchaseRequest.objects.count()
    pending_purchases = PurchaseRequest.objects.filter(status='oczekuje').count()
    popular_machines  = Machine.objects.annotate(rental_count=Count('rentals')).order_by('-rental_count')[:5]
    brands_stats      = Machine.objects.values('brand').annotate(count=Count('id')).order_by('-count')

    context = {
        'total_machines': total_machines,
        'available_machines': available_machines,
        'rented_machines': rented_machines,
        'for_sale_machines': for_sale_machines,
        'total_rentals': total_rentals,
        'pending_rentals': pending_rentals,
        'confirmed_rentals': confirmed_rentals,
        'total_revenue': total_revenue,
        'total_purchases': total_purchases,
        'pending_purchases': pending_purchases,
        'popular_machines': popular_machines,
        'brands_stats': brands_stats,
    }
    return render(request, 'machines/admin_stats.html', context)


def add_to_compare(request, pk):
    compare_list = request.session.get('compare_list', [])
    if pk not in compare_list:
        if len(compare_list) >= 4:
            messages.warning(request, 'Możesz porównać maksymalnie 4 maszyny.')
        else:
            compare_list.append(pk)
            request.session['compare_list'] = compare_list
            messages.success(request, 'Dodano do porównania!')
    else:
        messages.info(request, 'Ta maszyna jest już w porównaniu.')
    return redirect(request.META.get('HTTP_REFERER', 'catalog'))


def remove_from_compare(request, pk):
    compare_list = request.session.get('compare_list', [])
    if pk in compare_list:
        compare_list.remove(pk)
        request.session['compare_list'] = compare_list
        messages.success(request, 'Usunięto z porównania.')
    return redirect(request.META.get('HTTP_REFERER', 'catalog'))


def compare_machines(request):
    compare_list = request.session.get('compare_list', [])
    machines = Machine.objects.filter(pk__in=compare_list)
    return render(request, 'machines/compare.html', {'machines': machines})


def clear_compare(request):
    request.session['compare_list'] = []
    messages.success(request, 'Wyczyszczono listę porównania.')
    return redirect('catalog')


def payment_form(request, pk):
    rental = get_object_or_404(RentalRequest, pk=pk)
    if request.method == 'POST':
        rental.status = 'potwierdzona'
        rental.save()
        messages.success(request, 'Płatność przebiegła pomyślnie!')
        return redirect('payment_success', pk=rental.pk)
    return render(request, 'machines/payment_form.html', {'rental': rental})


def payment_success(request, pk):
    rental = get_object_or_404(RentalRequest, pk=pk)
    return render(request, 'machines/payment_success.html', {'rental': rental})
