from django.db import migrations, models
import django.db.models.deletion
import django.core.validators


class Migration(migrations.Migration):

    dependencies = [
        ('machines', '0003_machine_wiki_url_machine_youtube_url'),
        ('auth', '0012_alter_user_first_name_max_length'),
    ]

    operations = [
        migrations.CreateModel(
            name='Wishlist',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('added_at', models.DateTimeField(auto_now_add=True)),
                ('machine', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='wishlisted_by',
                    to='machines.machine',
                    verbose_name='Maszyna',
                )),
                ('user', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='wishlist',
                    to='auth.user',
                    verbose_name='Użytkownik',
                )),
            ],
            options={
                'verbose_name': 'Ulubiona maszyna',
                'verbose_name_plural': 'Ulubione maszyny',
                'unique_together': {('user', 'machine')},
            },
        ),
        migrations.CreateModel(
            name='MachineRating',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('rating', models.PositiveSmallIntegerField(
                    validators=[
                        django.core.validators.MinValueValidator(1),
                        django.core.validators.MaxValueValidator(5),
                    ],
                    verbose_name='Ocena (1–5)',
                )),
                ('comment', models.TextField(blank=True, verbose_name='Komentarz')),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('machine', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='ratings',
                    to='machines.machine',
                    verbose_name='Maszyna',
                )),
                ('user', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='ratings',
                    to='auth.user',
                    verbose_name='Użytkownik',
                )),
            ],
            options={
                'verbose_name': 'Ocena maszyny',
                'verbose_name_plural': 'Oceny maszyn',
                'unique_together': {('user', 'machine')},
                'ordering': ['-created_at'],
            },
        ),
    ]
