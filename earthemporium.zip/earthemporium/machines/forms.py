from django import forms
from .models import RentalRequest, PurchaseRequest
from datetime import date


class RentalForm(forms.ModelForm):
    class Meta:
        model = RentalRequest
        fields = ['full_name', 'email', 'phone', 'start_date', 'end_date', 'notes']
        widgets = {
            'full_name': forms.TextInput(attrs={'placeholder': 'Jan Kowalski', 'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'placeholder': 'jan.kowalski@email.com', 'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'placeholder': '+48 123 456 789', 'class': 'form-control'}),
            'start_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control', 'min': str(date.today())}),
            'end_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control', 'min': str(date.today())}),
            'notes': forms.Textarea(attrs={'rows': 3, 'class': 'form-control', 'placeholder': 'Dodatkowe uwagi...'}),
        }
        labels = {
            'full_name': 'Imię i nazwisko',
            'email': 'Adres e-mail',
            'phone': 'Numer telefonu',
            'start_date': 'Data rozpoczęcia',
            'end_date': 'Data zakończenia',
            'notes': 'Uwagi (opcjonalnie)',
        }

    def clean(self):
        cleaned_data = super().clean()
        start_date = cleaned_data.get('start_date')
        end_date = cleaned_data.get('end_date')

        if start_date and end_date:
            if start_date < date.today():
                raise forms.ValidationError('Data rozpoczęcia nie może być w przeszłości.')
            if end_date <= start_date:
                raise forms.ValidationError('Data zakończenia musi być późniejsza niż data rozpoczęcia.')
        return cleaned_data


class PurchaseForm(forms.ModelForm):
    class Meta:
        model = PurchaseRequest
        fields = ['full_name', 'email', 'phone', 'message']
        widgets = {
            'full_name': forms.TextInput(attrs={'placeholder': 'Jan Kowalski', 'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'placeholder': 'jan.kowalski@email.com', 'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'placeholder': '+48 123 456 789', 'class': 'form-control'}),
            'message': forms.Textarea(attrs={'rows': 4, 'class': 'form-control', 'placeholder': 'Napisz wiadomość...'}),
        }
        labels = {
            'full_name': 'Imię i nazwisko',
            'email': 'Adres e-mail',
            'phone': 'Numer telefonu',
            'message': 'Wiadomość (opcjonalnie)',
        }


class MachineFilterForm(forms.Form):
    TYPE_CHOICES = [('', 'Wszystkie typy')] + [
        ('gasienicowa', 'Koparka gąsienicowa'),
        ('kolowa', 'Koparka kołowa'),
        ('mini', 'Mini koparka'),
    ]
    STATUS_CHOICES = [('', 'Wszystkie statusy')] + [
        ('dostepna', 'Dostępna'),
        ('na_sprzedaz', 'Na sprzedaż'),
        ('wypozyczona', 'Wypożyczona'),
        ('nowa', 'Nowa'),
    ]
    BRAND_CHOICES = [('', 'Wszystkie marki')] + [
        ('CAT', 'CAT'),
        ('Komatsu', 'Komatsu'),
        ('Volvo', 'Volvo'),
        ('Liebherr', 'Liebherr'),
        ('JCB', 'JCB'),
        ('Hitachi', 'Hitachi'),
    ]
    SORT_CHOICES = [
        ('price_asc', 'Cena rosnąco'),
        ('price_desc', 'Cena malejąco'),
        ('name_asc', 'Nazwa A-Z'),
        ('newest', 'Najnowsze'),
    ]

    machine_type = forms.ChoiceField(choices=TYPE_CHOICES, required=False, label='Typ')
    status = forms.ChoiceField(choices=STATUS_CHOICES, required=False, label='Status')
    brand = forms.ChoiceField(choices=BRAND_CHOICES, required=False, label='Marka')
    price_min = forms.IntegerField(required=False, min_value=0, label='Cena min')
    price_max = forms.IntegerField(required=False, min_value=0, label='Cena max')
    sort = forms.ChoiceField(choices=SORT_CHOICES, required=False, label='Sortuj')
    search = forms.CharField(required=False, label='Szukaj', widget=forms.TextInput(attrs={'placeholder': 'Szukaj maszyny...'}))
