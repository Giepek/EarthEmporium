from django.core.management.base import BaseCommand
from machines.models import Machine


class Command(BaseCommand):
    help = 'Wypełnia bazę danych przykładowymi maszynami'

    def handle(self, *args, **options):
        machines_data = [
            {'name': 'CAT 320 GC', 'machine_type': 'gasienicowa', 'brand': 'CAT', 'status': 'dostepna',
             'year': 2022, 'weight_kg': 20000, 'digging_depth_m': 6.7, 'bucket_capacity_m3': 0.93,
             'engine_power_kw': 122, 'rental_price_per_day': 850, 'card_color': '#2e7d32',
             'is_featured': True, 'description': 'Koparka gąsienicowa CAT 320 GC to niezawodna maszyna do ciężkich prac ziemnych.'},
            {'name': 'Komatsu PC200', 'machine_type': 'gasienicowa', 'brand': 'Komatsu', 'status': 'na_sprzedaz',
             'year': 2019, 'weight_kg': 20100, 'digging_depth_m': 6.63, 'bucket_capacity_m3': 0.80,
             'engine_power_kw': 110, 'sale_price': 245000, 'card_color': '#e65100',
             'is_featured': True, 'description': 'Komatsu PC200 to jedna z najpopularniejszych koparek w swojej klasie.'},
            {'name': 'Volvo EC220E', 'machine_type': 'gasienicowa', 'brand': 'Volvo', 'status': 'dostepna',
             'year': 2021, 'weight_kg': 22800, 'digging_depth_m': 7.10, 'bucket_capacity_m3': 1.10,
             'engine_power_kw': 130, 'rental_price_per_day': 1100, 'card_color': '#1565c0',
             'is_featured': True, 'description': 'Volvo EC220E to wydajna koparka gąsienicowa z nowoczesnym systemem zarządzania.'},
            {'name': 'Liebherr R 920', 'machine_type': 'gasienicowa', 'brand': 'Liebherr', 'status': 'na_sprzedaz',
             'year': 2020, 'weight_kg': 20500, 'digging_depth_m': 6.78, 'bucket_capacity_m3': 0.95,
             'engine_power_kw': 120, 'sale_price': 380000, 'card_color': '#6a1b9a',
             'is_featured': True, 'description': 'Liebherr R 920 to precyzyjna koparka z doskonałą kontrolą ruchu.'},
            {'name': 'JCB JS220', 'machine_type': 'gasienicowa', 'brand': 'JCB', 'status': 'dostepna',
             'year': 2021, 'weight_kg': 21900, 'digging_depth_m': 6.59, 'bucket_capacity_m3': 0.90,
             'engine_power_kw': 115, 'rental_price_per_day': 780, 'card_color': '#2e7d32',
             'is_featured': True, 'description': 'JCB JS220 to sprawdzona koparka z systemem LiveLink do monitorowania.'},
            {'name': 'Hitachi ZX210', 'machine_type': 'gasienicowa', 'brand': 'Hitachi', 'status': 'na_sprzedaz',
             'year': 2018, 'weight_kg': 20700, 'digging_depth_m': 6.71, 'bucket_capacity_m3': 0.80,
             'engine_power_kw': 113, 'sale_price': 310000, 'card_color': '#e65100',
             'is_featured': False},
            {'name': 'CAT 308 CR', 'machine_type': 'mini', 'brand': 'CAT', 'status': 'dostepna',
             'year': 2023, 'weight_kg': 8200, 'digging_depth_m': 3.8, 'bucket_capacity_m3': 0.28,
             'engine_power_kw': 42, 'rental_price_per_day': 350, 'card_color': '#1565c0',
             'is_featured': False, 'description': 'Mini koparka CAT 308 CR idealna do prac w ciasnych przestrzeniach.'},
            {'name': 'Komatsu PW148', 'machine_type': 'kolowa', 'brand': 'Komatsu', 'status': 'nowa',
             'year': 2024, 'weight_kg': 15000, 'digging_depth_m': 5.8, 'bucket_capacity_m3': 0.65,
             'engine_power_kw': 96, 'rental_price_per_day': 650, 'sale_price': 420000, 'card_color': '#6a1b9a',
             'is_featured': False, 'description': 'Fabrycznie nowa koparka kołowa Komatsu PW148 — gotowa do pracy.'},
        ]

        created = 0
        for data in machines_data:
            if not Machine.objects.filter(name=data['name']).exists():
                Machine.objects.create(**data)
                created += 1
                self.stdout.write(f'  ✓ Dodano: {data["name"]}')

        self.stdout.write(self.style.SUCCESS(f'\nGotowe! Dodano {created} maszyn.'))
        if created < len(machines_data):
            self.stdout.write(self.style.WARNING(f'{len(machines_data) - created} maszyn już istniało.'))
