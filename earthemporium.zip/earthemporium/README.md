# EarthEmporium 🏗️
**Profesjonalny sprzęt budowlany — sprzedaż i wypożyczanie**


Projekt Django z pełnym frontendem do wynajmu i sprzedaży maszyn budowlanych.

---

## 📋 Wymagania

- Python 3.10+ ([pobierz](https://www.python.org/downloads/))
- pip (instalowany razem z Pythonem)

---

## 🚀 Pierwsze uruchomienie (Windows)

### Krok 1 — Otwórz terminal w folderze projektu
Kliknij prawym przyciskiem myszy na folder `earthemporium` → *Otwórz w terminalu*

### Krok 2 — Utwórz wirtualne środowisko
```bash
python -m venv venv
venv\Scripts\activate
```
> Na ekranie powinna pojawić się `(venv)` na początku linii

### Krok 3 — Zainstaluj zależności
```bash
pip install -r requirements.txt
```

### Krok 4 — Utwórz plik .env
Skopiuj plik `.env.example` i zmień jego nazwę na `.env`:
```bash
copy .env.example .env
```

### Krok 5 — Utwórz bazę danych
```bash
python manage.py makemigrations
python manage.py migrate
```

### Krok 6 — Dodaj przykładowe maszyny
```bash
python manage.py seed_machines
```

### Krok 7 — Utwórz konto admina
```bash
python manage.py createsuperuser
```
Podaj nazwę użytkownika, email i hasło.

### Krok 8 — Uruchom serwer
```bash
python manage.py runserver
```

Otwórz w przeglądarce: **http://127.0.0.1:8000/**

---

## 🚀 Pierwsze uruchomienie (Linux/Mac)

```bash
# Utwórz środowisko i aktywuj
python3 -m venv venv
source venv/bin/activate

# Zainstaluj
pip install -r requirements.txt

# .env
cp .env.example .env

# Baza danych
python manage.py makemigrations
python manage.py migrate

# Przykładowe dane
python manage.py seed_machines

# Konto admina
python manage.py createsuperuser

# Start!
python manage.py runserver
```

---
a
## 📱 Strony

| URL | Opis |
|-----|------|
| `http://127.0.0.1:8000/` | Strona główna |
| `http://127.0.0.1:8000/katalog/` | Katalog maszyn z filtrami |
| `http://127.0.0.1:8000/maszyna/1/` | Szczegóły maszyny |
| `http://127.0.0.1:8000/wypozycz/1/` | Formularz wypożyczenia |
| `http://127.0.0.1:8000/kup/1/` | Formularz zakupu |
| `http://127.0.0.1:8000/users/login/` | Logowanie |
| `http://127.0.0.1:8000/users/rejestracja/` | Rejestracja |
| `http://127.0.0.1:8000/users/profil/` | Profil użytkownika |
| `http://127.0.0.1:8000/kontakt/` | Kontakt |
| `http://127.0.0.1:8000/admin/` | Panel admina Django |

---

## ⚙️ Zarządzanie maszynami

Wejdź na **http://127.0.0.1:8000/admin/** i zaloguj się kontem admina.

W panelu możesz:
- Dodawać/edytować maszyny (nazwa, typ, cena, kolor karty, zdjęcie)
- Przeglądać i zarządzać rezerwacjami
- Zarządzać użytkownikami

**Ważne pola przy dodawaniu maszyny:**
- `Polecana` — zaznacz, żeby maszyna pojawiła się na stronie głównej
- `Status` — Dostępna / Na sprzedaż / Wypożyczona / Nowa
- `Kolor karty` — kolor tła na karcie w katalogu
- `Cena wynajmu` — wypełnij jeśli maszyna jest do wynajmu
- `Cena sprzedaży` — wypełnij jeśli maszyna jest na sprzedaż

---

## 🏭 Przygotowanie do hostingu

Przed wgraniem na serwer:

1. Zmień w `.env`:
```
DEBUG=False
SECRET_KEY=bardzo-dlugi-losowy-ciag-znakow-min-50-znakow
ALLOWED_HOSTS=twojadomena.pl,www.twojadomena.pl
```

2. Zbierz pliki statyczne:
```bash
python manage.py collectstatic
```

3. Dla bazy danych na produkcji rozważ PostgreSQL zamiast SQLite.

---

## 📁 Struktura projektu

```
earthemporium/
├── earthemporium/       # Konfiguracja Django
│   ├── settings.py      # Ustawienia
│   └── urls.py          # Główne URL-e
├── machines/            # Aplikacja maszyn
│   ├── models.py        # Modele bazy danych
│   ├── views.py         # Logika widoków
│   ├── forms.py         # Formularze
│   └── urls.py          # URL-e maszyn
├── users/               # Aplikacja użytkowników
│   ├── models.py        # Profil użytkownika
│   └── views.py         # Logowanie/rejestracja
├── templates/           # Szablony HTML
├── static/css/          # Style CSS
├── manage.py            # Narzędzie Django
└── requirements.txt     # Zależności
```
