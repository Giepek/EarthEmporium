from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    phone = models.CharField(max_length=20, blank=True, verbose_name='Telefon')
    company = models.CharField(max_length=100, blank=True, verbose_name='Firma')
    nip = models.CharField(max_length=20, blank=True, verbose_name='NIP')
    address = models.TextField(blank=True, verbose_name='Adres')

    class Meta:
        verbose_name = 'Profil użytkownika'
        verbose_name_plural = 'Profile użytkowników'

    def __str__(self):
        return f"Profil: {self.user.username}"
