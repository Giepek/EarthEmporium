#!/bin/bash
# ============================================
#  EarthEmporium — Skrypt pierwszego uruchomienia
# ============================================

echo "========================================"
echo "  EarthEmporium — Konfiguracja projektu"
echo "========================================"

# 1. Utwórz wirtualne środowisko
echo ""
echo "[1/6] Tworzenie wirtualnego środowiska Python..."
python -m venv venv
source venv/bin/activate

# 2. Zainstaluj zależności
echo ""
echo "[2/6] Instalacja zależności..."
pip install -r requirements.txt

# 3. Utwórz plik .env
echo ""
echo "[3/6] Tworzenie pliku .env..."
if [ ! -f .env ]; then
    cat > .env << 'EOF'
SECRET_KEY=django-insecure-zmien-ten-klucz-w-produkcji-na-losowy-ciag-znakow
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1
EOF
    echo "  ✓ Plik .env utworzony"
else
    echo "  ℹ Plik .env już istnieje"
fi

# 4. Migracje bazy danych
echo ""
echo "[4/6] Tworzenie bazy danych..."
python manage.py makemigrations
python manage.py migrate

# 5. Dane przykładowe
echo ""
echo "[5/6] Dodawanie przykładowych maszyn..."
python manage.py seed_machines

# 6. Superuser
echo ""
echo "[6/6] Tworzenie konta admina..."
echo ""
echo "  Podaj dane dla konta administratora:"
python manage.py createsuperuser

echo ""
echo "========================================"
echo "  ✓ Konfiguracja zakończona!"
echo ""
echo "  Uruchom serwer:"
echo "    source venv/bin/activate"
echo "    python manage.py runserver"
echo ""
echo "  Strona:        http://127.0.0.1:8000/"
echo "  Panel admina:  http://127.0.0.1:8000/admin/"
echo "========================================"
